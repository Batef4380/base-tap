# BaseTap ⚡

Tap-to-earn game on Base with batch transactions. Single approval = multiple on-chain transactions.

## Lokal Test

```bash
npm install
npm run dev
```

Tarayıcıda: http://localhost:3000

## Icon Oluştur

1. http://localhost:3000/icon.html aç
2. "Download icon.png" tıkla
3. "Download preview.png" tıkla
4. Dosyaları proje klasörüne taşı

## Deploy

### 1. GitHub'a Yükle

```bash
git init
git add .
git commit -m "first commit"
git branch -M main
git remote add origin [REPO_URL]
git push -u origin main
```

### 2. Vercel'e Deploy

1. vercel.com'a git
2. GitHub reposunu bağla
3. Deploy et
4. URL'i al

### 3. Smart Contract Deploy (Base Sepolia)

```bash
# Foundry kur
curl -L https://foundry.paradigm.xyz | bash
foundryup

# Deploy et
forge create BaseTap.sol:BaseTap \
  --rpc-url https://sepolia.base.org \
  --private-key [PRIVATE_KEY]
```

Contract adresini `game.js` içindeki `CONTRACT_ADDRESS`'e yaz.

### 4. Farcaster Doğrulama

1. https://warpcast.com/~/developers/mini-apps git
2. Vercel URL'ini gir
3. accountAssociation bilgilerini al
4. `.well-known/farcaster.json` dosyasını güncelle
5. Tüm `[DOMAIN]` yerlerini Vercel URL'in ile değiştir

### 5. Güncelle ve Push

```bash
git add .
git commit -m "Update config"
git push
```

## Dosya Yapısı

```
basetap/
├── index.html          # Ana uygulama
├── style.css           # Stiller
├── game.js             # Oyun mantığı + Web3
├── icon.html           # Icon generator
├── icon.png            # Uygulama iconu (oluştur)
├── preview.png         # Preview resmi (oluştur)
├── BaseTap.sol         # Smart contract
├── package.json
└── .well-known/
    └── farcaster.json  # Farcaster manifest
```
